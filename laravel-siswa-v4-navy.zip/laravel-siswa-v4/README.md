# 📚 Laravel Pendaftaran Siswa V3 — Full Featured

## ✨ Fitur Lengkap
| Fitur | Keterangan |
|---|---|
| 🔐 Login Admin | Email + password, ingat saya |
| 🔑 Ganti Password | Dengan validasi password lama |
| 📊 Dashboard | Statistik lengkap + grafik |
| 📋 CRUD Siswa | Tambah, lihat, edit, hapus |
| 🔢 No. Pendaftaran | Generate otomatis SMK-2025-0001 |
| 📸 Upload Foto | Preview foto, fallback ke avatar |
| 🔍 Pencarian | Cari nama, no. daftar, sekolah |
| 🖨️ Print PDF | Langsung cetak dari browser |
| 📊 Export Excel | Download file CSV/Excel |
| ✅ Halaman Sukses | Tampilkan no. pendaftaran setelah daftar |

## 🔑 Akun Admin Default
- Email: `admin@smkcoding.sch.id`
- Password: `admin123`

---

## 🚀 Cara Install

### 1. Copy semua file ke project Laravel
Salin semua file dari ZIP sesuai strukturnya.

### 2. Setting .env
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=pendaftaran_siswa
DB_USERNAME=root
DB_PASSWORD=
```

### 3. Jalankan perintah ini
```bash
php artisan migrate:fresh
php artisan db:seed --class=AdminSeeder
php artisan storage:link
php artisan serve
```

> ⚠️ `php artisan storage:link` WAJIB dijalankan agar foto bisa tampil!

---

## 🌐 URL Penting

| URL | Akses | Keterangan |
|---|---|---|
| `/` | Publik | Halaman beranda |
| `/daftar` | Publik | Form pendaftaran |
| `/pendaftar` | Publik | Lihat daftar (tanpa edit/hapus) |
| `/login` | Admin | Halaman login |
| `/dashboard` | Admin | Dashboard statistik |
| `/siswa` | Admin | Kelola data siswa |
| `/siswa-print` | Admin | Print PDF |
| `/siswa-export` | Admin | Export Excel/CSV |
| `/ganti-password` | Admin | Ganti password |
